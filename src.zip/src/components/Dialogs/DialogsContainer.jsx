import Dialogs from './Dialogs';
import { connect } from 'react-redux';
import React from 'react';
import { getDialogsItemsThunk } from '../../redux/reducers/dialogs_reducer';
import withRedirect from '../../hoc/withRedirect';
import { compose } from 'redux';

class DialogsContainer extends React.Component {

  componentDidMount(){
    this.props.getDialogsItemsThunk();
  }

  render(){
    return <Dialogs dialogs={this.props.dialogs} />
  }
}

let mapStateToProps = (state) => {
  return { dialogs: state.dialogs }
}
export default compose(
  connect(mapStateToProps, { getDialogsItemsThunk }),
  withRedirect
)(DialogsContainer);