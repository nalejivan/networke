import React from 'react';

const Login = (props) => {
  return <h2>Login</h2>
}
export default Login;