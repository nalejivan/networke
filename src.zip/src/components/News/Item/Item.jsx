import React from 'react';
import img from './post.png';

const Item = (props) => {
  return(
    props.news.map((item, i) => 
      <div key={'news_' + i}>
        <img src={img} alt='post'/>
        <div>{item.text}</div>
      </div>
    )
  )
}
export default Item;