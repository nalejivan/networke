import React from 'react';
import s from './News.module.css';

const News = (props) => {
  return(
    <div>
      <input value={props.text} onChange={ e => { props.setTextThunk(e.target.value)}}/>
      <input type='button' value='Опубликовать' onClick={ () => props.setNewsThunk() }/>
      <div className={s.news}>
        {props.item}
      </div>
    </div>
  )
}
export default News;