import React from 'react';

import { setTextThunk, setNewsThunk } from '../../redux/reducers/news_reducer';
import Item from './Item/Item';
import News from './News';
import { connect } from 'react-redux';

let mapStateToProps = (state) => {
  return {
    text: state.news.text,
    item: <Item news={state.news.arr}/>
  }
}

const  NewsContainer = connect(mapStateToProps,
  { 
    setTextThunk, 
    setNewsThunk
  })(News)
export default NewsContainer;