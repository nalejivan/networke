import React from 'react';
import { Redirect } from 'react-router-dom';
import { connect } from 'react-redux';

let withRedirect = (Component) => {
  let mapStateToProps = (state) => {
    return { auth: state.auth.auth }
  }
  let wrapRedirect = (props) => {
    debugger
      if (props.auth === true){
        return <Component {...props} />;
      } else {
        return <Redirect to='/login' />;
      }
  }
  return connect(mapStateToProps)(wrapRedirect);;
}
export default withRedirect;