const GET_DIALOGS_ITEMS = 'GET_DIALOGS_ITEMS';

/** REDUCERS */
const initialState = [
    { 
      user: 'One',
      message: 'Hi!'
    },
    { 
      user: 'Two',
      message: 'Hello!'
    }
];

let auth_reducer = (state = initialState, action) => {
  switch(action.type){
    case GET_DIALOGS_ITEMS:
      return state;
    default:
      return state;
  }
}
  
export default auth_reducer;

/** ACTION CREATOS */
const getDialogs = ()  => {
  return {
    type: GET_DIALOGS_ITEMS
  }
}

/** THUNKS */
const getDialogsItemsThunk = () => {
  return dispath => {
    // authIpi.getUserData().then(data => {
    //   dispath(setUserData(data.id, data.login, data.email));
    // });
    dispath(getDialogs());
  }
}
export { getDialogs, getDialogsItemsThunk }
