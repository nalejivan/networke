const SET_NEWS = 'SET_NEWS';
const SET_TEXT = 'SET_TEXT';

/** REDUCERS */
const initialState = {
  arr: [
    {text: 'Прекрасная погода, светит солнце! Хочу пиво!'},
    {text: 'Темное пиво и чипысы, члучше чем кодить!'}
  ],
  text: 'test'
}
let news_reducer = (state = initialState, action) => {
  switch(action.type){
    case SET_NEWS:
      return {
        ...state, 
          arr: [...state.arr, {text: state.text}], 
          text: ''
      };
    case SET_TEXT:
      return {
        ...state, text: action.text
      }
    default:
      return state;
  }
}
  
export default news_reducer;

/** ACTION CREATOS */
const setText = (text)  => {
  return {
    type: SET_TEXT,
    text: text
  }
}
const setNews = ()  => {
  return {
    type: SET_NEWS
  }
}
/** THUNKS */
const setTextThunk = (text) => {
  return dispath => {
    dispath(setText(text));
  }
}
const setNewsThunk = (news) => {
  return dispath => {
    dispath(setNews(news));
  }
}
export { setTextThunk, setNewsThunk }
