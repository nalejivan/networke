import { createStore, combineReducers, applyMiddleware } from 'redux';
import status_reducer from './reducers/status_reducer';
import auth_reducer from './reducers/auth_reducer';
import users_reducer from './reducers/users_reducer';
import profile_reducer from './reducers/profile_reducer';
import dialogs_reducer from './reducers/dialogs_reducer';
import news_reducer from './reducers/news_reducer';
import thunk from 'redux-thunk';
import { composeWithDevTools } from 'redux-devtools-extension';


  // news: {
  //   arr: [
  //     {text: 'Прекрасная погода, светит солнце! Хочу пиво!'},
  //     {text: 'Темное пиво и чипысы, члучше чем кодить!'}
  //   ],
  //   textValue: '1'
  // },


let reducers = combineReducers({
  auth: auth_reducer,
  users: users_reducer,
  userProfile: profile_reducer,
  dialogs: dialogs_reducer,
  news: news_reducer,
  status: status_reducer
});
let store = createStore(reducers, composeWithDevTools(applyMiddleware(thunk)));
//compose(window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__()),
export default store;
window.store = store